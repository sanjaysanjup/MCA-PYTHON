word = input("Enter the word:") 
print("Ordinal Values of ", word, "are:") 
for x in word: 
    print(x, " : ", ord(x))
