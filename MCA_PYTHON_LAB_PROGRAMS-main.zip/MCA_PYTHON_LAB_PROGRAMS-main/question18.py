string1 = input("Enter first string :") 
string2 = input("Enter second string :") 
stringn = string2[0] + string1[1:] + " " + string1[0] + string2[1:] 
print (stringn)
