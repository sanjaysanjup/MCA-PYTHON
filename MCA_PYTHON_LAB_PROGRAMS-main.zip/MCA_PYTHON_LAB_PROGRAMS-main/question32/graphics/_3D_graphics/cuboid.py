def surface_area(length, width, height):
    return 2 * (length * width + length * height + width * height)

def volume(length, width, height):
    return length * width * height
