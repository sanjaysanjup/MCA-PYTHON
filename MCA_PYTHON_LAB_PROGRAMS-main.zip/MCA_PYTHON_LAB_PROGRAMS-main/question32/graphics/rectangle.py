def area(length, width):
    return length * width

def perimeter(length, width):
    return 2 * (length + width)
