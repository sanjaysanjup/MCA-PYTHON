file = input("Enter the filename:") 
file_list = file.split(".") 
print("File Extension is : ", file_list[-1])
