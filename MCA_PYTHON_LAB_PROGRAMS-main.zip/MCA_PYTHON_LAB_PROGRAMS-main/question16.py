n = int(input("ENTER THE VALUE OF 'n':")) 
print("n + nn + nnn =", n + (n*n) + (n*n*n))
