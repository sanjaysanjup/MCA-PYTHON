n = int(input("ENTER NUMBER:")) 
sq = [i**2 for i in range(1, n+1)]  
print("Square of first ", n, " numbers:", sq)
