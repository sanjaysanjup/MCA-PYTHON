num = [21, -4, 21, 100, -3] 
print("List:",num) 
print("Positive Numbers:") 
for x in num: 
    if (x > 0): 
        print(x)
