print("Enter 3 Numbers:") 
n1 = int(input()) 
n2 = int(input()) 
n3 = int(input()) 
if (n1 > n2 and n1 > n3): 
    print(n1, " is the biggest!!") 
elif (n2 > n3): 
    print(n2, " is the biggest!!") 
else: 
    print(n3, " is the biggest!!")
